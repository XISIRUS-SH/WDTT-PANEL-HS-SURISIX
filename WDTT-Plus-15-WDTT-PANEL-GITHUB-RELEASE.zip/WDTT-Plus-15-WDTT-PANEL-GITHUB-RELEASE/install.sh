#!/usr/bin/env bash
set -Eeuo pipefail

# WDTT Panel installer / updater.
# Usage:
#   curl -fsSL https://raw.githubusercontent.com/XISIRUS-SH/WDTT-Plus-15-WDTT-PANEL/main/install.sh | sudo bash
#
# The installer intentionally refuses to guess the repository URL when copied
# elsewhere. Set WDTT_REPO_RAW to your raw GitHub base URL if you publish under
# a different owner/repository.

RAW_BASE="${WDTT_REPO_RAW:-https://raw.githubusercontent.com/XISIRUS-SH/WDTT-Plus-15-WDTT-PANEL/main}"
PREFIX="${WDTT_PANEL_PREFIX:-/opt/wdtt-panel}"
BIN="/usr/local/bin/wdtt-panel"
UNIT="/etc/systemd/system/wdtt-panel.service"
CONF="/etc/wdtt/panel.env"
PORT="${WDTT_PANEL_PORT:-8787}"
BACKUP="$PREFIX/backups/$(date +%Y%m%d-%H%M%S)"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run as root (use sudo)." >&2
  exit 1
fi

echo "== WDTT Panel installer =="
echo "Raw source: $RAW_BASE"
echo "Install dir: $PREFIX"
echo "Panel port: $PORT"

if command -v ss >/dev/null 2>&1 && ss -ltnH | awk '{print $4}' | grep -Eq "[:.]${PORT}$"; then
  echo "ERROR: TCP port $PORT is already occupied. Set WDTT_PANEL_PORT or stop the conflicting service." >&2
  exit 1
fi

mkdir -p "$PREFIX" "$BACKUP" /etc/wdtt

# Never touch the existing WDTT database/config.
for f in "$BIN" "$UNIT" "$CONF"; do
  [[ -e "$f" ]] && cp -a "$f" "$BACKUP/" || true
done

tmp="$(mktemp)"
trap 'rm -f "$tmp"' EXIT

# The repository release must contain a prebuilt Linux binary under releases/.
# If it does not, fail loudly instead of installing a fake/demo binary.
url="$RAW_BASE/releases/linux-amd64/wdtt-panel"
echo "Downloading $url"
if ! curl -fL --retry 3 --connect-timeout 10 "$url" -o "$tmp"; then
  echo "ERROR: release binary unavailable at $url" >&2
  echo "Build/publish the release artifact first; installer will not fabricate one." >&2
  exit 1
fi
chmod 0755 "$tmp"

install -m 0755 "$tmp" "$BIN"

cat > "$CONF" <<EOF
# WDTT Panel environment
WDTT_PANEL_LISTEN=127.0.0.1:${PORT}
# Set a strong existing WDTT main password through your existing server config.
EOF
chmod 0600 "$CONF"

cat > "$UNIT" <<EOF
[Unit]
Description=WDTT Panel integration
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=$BIN --panel-listen 127.0.0.1:$PORT
Restart=on-failure
RestartSec=2
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
if systemctl restart wdtt-panel.service; then
  echo "WDTT Panel service restarted."
else
  echo "ERROR: restart failed; restoring previous files." >&2
  [[ -f "$BACKUP/wdtt-panel" ]] && cp -a "$BACKUP/wdtt-panel" "$BIN" || true
  [[ -f "$BACKUP/wdtt-panel.service" ]] && cp -a "$BACKUP/wdtt-panel.service" "$UNIT" || true
  systemctl daemon-reload
  systemctl restart wdtt-panel.service 2>/dev/null || true
  exit 1
fi

echo
echo "Installation complete."
echo "Local panel: http://127.0.0.1:$PORT/panel/"
echo
echo "=== LIVE LOGS ==="
echo "Press Ctrl-C when you have enough logs."
echo
journalctl -u wdtt-panel.service -n 100 -f
