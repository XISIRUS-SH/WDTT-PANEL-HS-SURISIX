#!/usr/bin/env bash
set -Eeuo pipefail

PREFIX="${WDTT_PANEL_PREFIX:-/opt/wdtt-panel}"
BIN="/usr/local/bin/wdtt-panel"
UNIT="/etc/systemd/system/wdtt-panel.service"
CONF="/etc/wdtt/panel.env"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run as root." >&2
  exit 1
fi

echo "This removes ONLY the WDTT Panel integration."
echo "It does NOT remove WDTT's existing database, WireGuard keys, configs, or service."
read -r -p "Type REMOVE-WDTT-PANEL to continue: " answer
[[ "$answer" == "REMOVE-WDTT-PANEL" ]] || { echo "Cancelled."; exit 1; }

systemctl disable --now wdtt-panel.service 2>/dev/null || true
rm -f "$UNIT" "$BIN" "$CONF"
rm -rf "$PREFIX"
systemctl daemon-reload

echo "WDTT Panel removed."
echo "Existing WDTT data/service were intentionally left untouched."
