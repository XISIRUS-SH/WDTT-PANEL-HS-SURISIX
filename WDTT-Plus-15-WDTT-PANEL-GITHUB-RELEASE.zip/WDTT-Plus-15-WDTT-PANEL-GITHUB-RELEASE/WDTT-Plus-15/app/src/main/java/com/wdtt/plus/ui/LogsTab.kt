package com.wdtt.plus.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wdtt.plus.LogEntry
import com.wdtt.plus.LogSeverity
import com.wdtt.plus.TunnelManager
import com.wdtt.plus.WDTTColors
import com.wdtt.plus.SettingsStore
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogsTab(
    firstVisibleItemIndex: MutableIntState = rememberSaveable { mutableIntStateOf(0) },
    firstVisibleItemScrollOffset: MutableIntState = rememberSaveable { mutableIntStateOf(0) }
) {
    val context = LocalContext.current
    val settingsStore = remember { SettingsStore(context) }
    val loggingEnabled by settingsStore.loggingEnabled.collectAsStateWithLifecycle(initialValue = true)
    val scope = rememberCoroutineScope()
    val currentLogs by TunnelManager.logs.collectAsStateWithLifecycle()
    val tunnelRunning by TunnelManager.running.collectAsStateWithLifecycle()
    val listState = rememberRememberedLazyListState(
        firstVisibleItemIndex,
        firstVisibleItemScrollOffset
    )

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Toolbar
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Лог событий",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Row {
                IconButton(onClick = { TunnelManager.clearLogs() }) {
                    Icon(Icons.Default.Delete, contentDescription = "Clear", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = {
                    val text = currentLogs.joinToString("\n") { "${it.message} (x${it.count})" }
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = ClipData.newPlainText("WDTT Logs", text)
                    clipboard.setPrimaryClip(clip)
                    Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                }) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }

        // Карточка-выключатель логирования
        AppSectionCard(
            modifier = Modifier.padding(bottom = 12.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "Активное логирование",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Switch(
                    checked = loggingEnabled,
                    onCheckedChange = { enabled ->
                        scope.launch {
                            settingsStore.saveLoggingEnabled(enabled)
                            if (!enabled) {
                                TunnelManager.clearLogs()
                            }
                        }
                    }
                )
            }
        }

        // Нейтральный фон в светлой теме не спорит с цветами уровней лога.
        val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
        val terminalBg = if (isDark) {
            WDTTColors.terminalBgDark
        } else {
            MaterialTheme.colorScheme.surfaceContainerHighest
        }

        Card(
            modifier = Modifier.fillMaxSize(),
            colors = CardDefaults.cardColors(containerColor = terminalBg),
            shape = RoundedCornerShape(20.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(12.dp),
                contentPadding = PaddingValues(bottom = 12.dp)
            ) {
                items(currentLogs, key = { it.key }) { entry ->
                    LogLine(entry, sessionActive = tunnelRunning)
                }
            }
        }
    }
}

@Composable
fun LogLine(entry: LogEntry, sessionActive: Boolean) {
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val activeColor = when {
        entry.severity == LogSeverity.Error -> if (isDark) WDTTColors.terminalRed else MaterialTheme.colorScheme.error
        entry.severity == LogSeverity.Warning -> if (isDark) WDTTColors.terminalYellow else MaterialTheme.colorScheme.tertiary
        entry.priority <= 2 -> if (isDark) WDTTColors.terminalGreen else WDTTColors.onConnected
        entry.priority == 3 -> if (isDark) WDTTColors.terminalBlue else MaterialTheme.colorScheme.primary
        else -> if (isDark) WDTTColors.terminalText else MaterialTheme.colorScheme.onSurface
    }
    val isStoppedStats = entry.key == "stats" &&
        (entry.message.contains("VPN отключён") || entry.message.contains("VPN в ожидании"))
    val color = when {
        sessionActive -> activeColor
        isStoppedStats -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.9f)
        else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.68f)
    }
    val counterColor = if (sessionActive) {
        WDTTColors.terminalBlue
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (isStoppedStats) 0.85f else 0.68f)
    }

    var trigger by remember { mutableIntStateOf(0) }
    LaunchedEffect(entry.count) { trigger++ }

    val animatedScale by animateFloatAsState(
        targetValue = if (trigger > 0) 1.15f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "scale",
        finishedListener = { trigger = 0 }
    )

    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            color = if (isDark) {
                WDTTColors.terminalCounter.copy(alpha = 0.2f)
            } else {
                MaterialTheme.colorScheme.primaryContainer
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .defaultMinSize(minWidth = 24.dp, minHeight = 24.dp)
                .graphicsLayer(scaleX = animatedScale, scaleY = animatedScale)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.padding(horizontal = 6.dp)
            ) {
                Text(
                    text = "${entry.count}",
                    color = counterColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Text(
            text = entry.message,
            color = color,
            fontSize = 13.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = when (entry.severity) {
                LogSeverity.Error -> FontWeight.Bold
                LogSeverity.Warning -> FontWeight.Medium
                LogSeverity.Info -> FontWeight.Normal
            },
            lineHeight = 18.sp,
            modifier = Modifier.weight(1f)
        )
    }
}
